"""Поиск рамок полей на изображении (OpenCV)."""
import cv2
import numpy as np

from .geometry import iou


def find_rects(img):
    """Находит рамки полей по горизонтальным/вертикальным линиям. Возвращает [(x1,y1,x2,y2)]."""
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    bw = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 25, 15)

    k = max(15, min(w, h) // 50)  # минимальная длина линии
    horiz = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (k, 1)))
    vert = cv2.morphologyEx(bw, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, k)))
    lines = cv2.dilate(cv2.bitwise_or(horiz, vert), np.ones((3, 3), np.uint8), iterations=2)

    contours, _ = cv2.findContours(lines, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    rects = []
    for c in contours:
        x, y, rw, rh = cv2.boundingRect(c)
        if rw < 3 * k or rh < k * 0.6:  # слишком мелкие
            continue
        if rw * rh > 0.5 * w * h:  # рамка всей страницы
            continue
        # контур рамки должен быть «прямоугольным»
        if cv2.contourArea(c) < 0.8 * rw * rh and len(cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)) != 4:
            continue
        rects.append((x, y, x + rw, y + rh))

    # дедупликация (внешний и внутренний контур линии почти совпадают)
    rects.sort(key=lambda r: (r[2] - r[0]) * (r[3] - r[1]), reverse=True)
    out = []
    for r in rects:
        if not any(iou(r, o) > 0.8 for o in out):
            out.append(r)
    return out
