"""Текстовый слой PDF: проверка пригодности и извлечение фрагментов с координатами (в пикселях рендера)."""


def text_layer_ok(text, min_chars=20):
    """Пригоден ли текстовый слой страницы (есть текст и он не мусорный)."""
    chars = [c for c in text if not c.isspace()]
    if len(chars) < min_chars:
        return False
    bad = sum(1 for c in chars if c == "\ufffd" or "\ue000" <= c <= "\uf8ff") + 4 * text.count("(cid:")
    good = sum(1 for c in chars if c.isalnum())
    return bad / len(chars) < 0.1 and good / len(chars) > 0.5


def pymupdf_items(page, scale):
    """Фрагменты из страницы pymupdf (слова одной строки склеиваются, пока нет большого разрыва)."""
    import pymupdf

    words = sorted(page.get_text("words"), key=lambda w: (w[5], w[6], w[7]))
    items, cur = [], None
    for x0, y0, x1, y1, t, blk, ln, _ in words:
        r = pymupdf.Rect(x0, y0, x1, y1) * page.rotation_matrix * scale
        box = [r.x0, r.y0, r.x1, r.y1]
        if cur and cur["key"] == (blk, ln) and box[0] - cur["box"][2] < 1.0 * (box[3] - box[1]):
            cur["text"] += " " + t
            cur["box"] = [min(cur["box"][0], box[0]), min(cur["box"][1], box[1]),
                          max(cur["box"][2], box[2]), max(cur["box"][3], box[3])]
        else:
            if cur:
                items.append(cur)
            cur = {"key": (blk, ln), "text": t, "box": box}
    if cur:
        items.append(cur)
    return [{"text": i["text"].strip(), "score": 1.0, "box": tuple(int(v) for v in i["box"])}
            for i in items if i["text"].strip()]


def pdfplumber_items(page, scale):
    """Слова из страницы pdfplumber.

    Слова не склеиваем: границы рамок между ними неизвестны, поля собирает build_fields.
    """
    words = sorted(page.extract_words(), key=lambda w: (round(w["top"]), w["x0"]))
    return [{"text": w["text"], "score": 1.0,
             "box": tuple(int(v * scale) for v in (w["x0"], w["top"], w["x1"], w["bottom"]))}
            for w in words]
