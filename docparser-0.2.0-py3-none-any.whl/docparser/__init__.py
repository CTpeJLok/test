"""Извлечение полей «название -> значение в рамке» из сканов и PDF через PaddleOCR."""
from .ocr import HttpBackend, PaddleBackend
from .pipeline import parse_file, parse_pdfplumber

__all__ = ["parse_file", "parse_pdfplumber", "HttpBackend", "PaddleBackend"]
