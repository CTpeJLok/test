"""Основной конвейер: страница -> (текстовый слой | OCR) + рамки -> поля."""
from .fields import build_fields
from .loaders import load_pages, plumber_pages
from .ocr import PaddleBackend, run_ocr
from .rects import find_rects


def process_pages(pages, name, ocr):
    """pages — итератор (img, items|None); items=None -> OCR. ocr — бэкенд (см. ocr.py)."""
    out = []
    for n, (img, items) in enumerate(pages, 1):
        source = "text_layer"
        if items is None:
            source = "ocr"
            items = run_ocr(ocr, img)
        title, fields, rest = build_fields(items, find_rects(img))
        out.append({"page": n, "source": source, "title": title, "fields": fields, "unassigned_text": rest})
    return {"file": str(name), "pages": out}


def parse_file(path, ocr=None, dpi=200, force_ocr=False, lang="ru"):
    """PDF или картинка с диска -> dict. ocr — бэкенд; по умолчанию локальный PaddleBackend(lang)."""
    return process_pages(load_pages(path, dpi, force_ocr), path, ocr or PaddleBackend(lang))


def parse_pdfplumber(pdf, name="<pdfplumber>", ocr=None, dpi=200, force_ocr=False, lang="ru"):
    """Уже открытый pdfplumber.PDF -> dict. ocr — бэкенд; по умолчанию локальный PaddleBackend(lang)."""
    return process_pages(plumber_pages(pdf, dpi, force_ocr), name, ocr or PaddleBackend(lang))
