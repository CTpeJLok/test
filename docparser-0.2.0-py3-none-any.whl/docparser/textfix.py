"""Постобработка распознанного текста."""

# Латинские буквы, неотличимые от кириллических (и наоборот)
_LAT2CYR = dict(zip("ABCEHKMOPTXYaceopxyk", "АВСЕНКМОРТХУасеорхук"))
_CYR2LAT = {v: k for k, v in _LAT2CYR.items()}
_LAT = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
_CYR = set("АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя")


def fix_mixed_script(text):
    """Слово с латиницей и кириллицей одновременно -> один алфавит, если различия только в омоглифах.

    «Hoмер» (лат. H, o) -> «Номер». Чисто латинские/чисто кириллические слова не трогаем.
    """
    def fix(word):
        lat = [c for c in word if c in _LAT]
        cyr = [c for c in word if c in _CYR]
        if not lat or not cyr:
            return word
        if all(c in _LAT2CYR for c in lat):  # приоритет — кириллица
            return "".join(_LAT2CYR.get(c, c) for c in word)
        if all(c in _CYR2LAT for c in cyr):
            return "".join(_CYR2LAT.get(c, c) for c in word)
        return word  # настоящий микс (напр. «Москва-City») не трогаем

    return " ".join(fix(w) for w in text.split(" "))
