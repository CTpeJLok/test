"""OCR-бэкенды. Бэкенд — любой объект с методом `recognize(img_bgr) -> [{'text','score','box'}]`,
где box = (x1, y1, x2, y2) в пикселях переданного изображения.

  * PaddleBackend — локальный PaddleOCR (нужен extra `docparser[paddle]`), модель грузится при первом вызове.
  * HttpBackend   — внешний сервис по HTTP (см. контракт в классе).
"""
import json
import urllib.error
import urllib.request

import cv2

from .textfix import fix_mixed_script


class PaddleBackend:
    def __init__(self, lang="ru", engine=None):
        """engine — уже созданный объект paddleocr.PaddleOCR (необязательно)."""
        self.lang = lang
        self._engine = engine

    def _load(self):
        try:
            from paddleocr import PaddleOCR
        except ImportError as e:
            raise RuntimeError(
                "PaddleOCR не установлен. Поставьте `pip install 'docparser[paddle]'` "
                "или используйте внешний сервис (HttpBackend / --ocr-url)."
            ) from e
        return PaddleOCR(
            lang=self.lang,
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
            use_textline_orientation=False,
            enable_mkldnn=False,  # обход бага oneDNN/PIR в Paddle 3.x на CPU
        )

    def recognize(self, img):
        if self._engine is None:
            self._engine = self._load()
        res = self._engine.predict(img)[0]
        return [{"text": t, "score": float(s), "box": tuple(int(v) for v in b)}
                for t, s, b in zip(res["rec_texts"], res["rec_scores"], res["rec_boxes"])]


class HttpBackend:
    """Клиент внешнего OCR-сервиса.

    Контракт:
      запрос:  POST <url>, тело — PNG-байты, `Content-Type: image/png`
      ответ:   200, JSON: {"text": "...", "time": 0.0,
                           "items": [{"text": "Иванов", "x1": 10, "y1": 20, "x2": 110, "y2": 60, "score": 0.99}]}
               Используется только "items"; координаты — в пикселях присланной картинки.
      timeout — секунды ожидания данных от сервера (на каждое ожидание, не общий лимит запроса);
               холодный старт сервиса с загрузкой модели учитывайте здесь же.
    """

    def __init__(self, url, timeout=300, headers=None):
        self.url = url
        self.timeout = timeout
        self.headers = {"Content-Type": "image/png", **(headers or {})}

    def recognize(self, img):
        ok, buf = cv2.imencode(".png", img)
        if not ok:
            raise ValueError("не удалось закодировать изображение в PNG")
        req = urllib.request.Request(self.url, data=buf.tobytes(), headers=self.headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"OCR-сервис {self.url}: HTTP {e.code}: {e.read()[:200]!r}") from e
        except TimeoutError as e:  # ответ не пришёл за timeout секунд (таймаут на каждое ожидание данных)
            raise RuntimeError(
                f"OCR-сервис {self.url} не ответил за {self.timeout} с; увеличьте timeout (--ocr-timeout)"
            ) from e
        except urllib.error.URLError as e:
            if isinstance(e.reason, TimeoutError):  # таймаут при установке соединения
                raise RuntimeError(f"OCR-сервис {self.url}: таймаут соединения ({self.timeout} с)") from e
            raise RuntimeError(f"OCR-сервис {self.url} недоступен: {e.reason}") from e

        return [{"text": str(i["text"]), "score": float(i["score"]),
                 "box": tuple(int(i[k]) for k in ("x1", "y1", "x2", "y2"))} for i in data["items"]]


def run_ocr(backend, img):
    """Распознаёт страницу и чистит текст (общая постобработка для любого бэкенда)."""
    items = []
    for it in backend.recognize(img):
        t = fix_mixed_script(it["text"].strip())
        if t:
            items.append({**it, "text": t})
    return items
