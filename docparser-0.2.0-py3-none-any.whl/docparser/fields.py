"""Сборка полей «название -> значение» из текстовых фрагментов и рамок."""
from .geometry import center, v_overlap


def join_lines(items):
    """Склеивает фрагменты: сверху вниз, внутри строки слева направо."""
    items = sorted(items, key=lambda i: (center(i["box"])[1], i["box"][0]))
    rows, cur = [], []
    for it in items:
        if cur and v_overlap(cur[-1]["box"], it["box"]) < 0.5:
            rows.append(cur)
            cur = []
        cur.append(it)
    if cur:
        rows.append(cur)
    return " ".join(" ".join(i["text"] for i in sorted(r, key=lambda i: i["box"][0])) for r in rows)


def build_fields(items, rects):
    """-> (title, fields, leftovers)."""
    # текст -> самая маленькая рамка, внутри которой лежит его центр
    boxed = {i: [] for i in range(len(rects))}
    free = []
    for it in items:
        cx, cy = center(it["box"])
        hit = [i for i, r in enumerate(rects) if r[0] <= cx <= r[2] and r[1] <= cy <= r[3]]
        if hit:
            boxed[min(hit, key=lambda i: (rects[i][2] - rects[i][0]) * (rects[i][3] - rects[i][1]))].append(it)
        else:
            free.append(it)

    # Контейнеры (рамка, содержащая другие рамки) — не поля.
    def contains(a, b):
        return a != b and a[0] <= b[0] + 2 and a[1] <= b[1] + 2 and a[2] >= b[2] - 2 and a[3] >= b[3] - 2

    leaf = [i for i, r in enumerate(rects) if not any(contains(r, o) for o in rects)]
    leaf.sort(key=lambda i: (center(rects[i])[1], rects[i][0]))

    # группировка рамок в строки
    rows = []
    for i in leaf:
        if rows and v_overlap(rects[rows[-1][-1]], rects[i]) > 0.5:
            rows[-1].append(i)
        else:
            rows.append([i])

    top = min((rects[i][1] for i in leaf), default=10**9)
    title = join_lines([f for f in free if center(f["box"])[1] < top and not any(
        v_overlap(f["box"], rects[i]) > 0.3 for i in leaf)])

    fields, used = [], set()
    for row in rows:
        row.sort(key=lambda i: rects[i][0])
        left_limit = 0
        for i in row:
            r = rects[i]
            cand = [
                (k, f) for k, f in enumerate(free)
                if k not in used and f["box"][2] <= r[0] + 5 and center(f["box"])[0] >= left_limit
                and v_overlap(f["box"], r) > 0.3
            ]
            for k, _ in cand:
                used.add(k)
            vals = boxed[i]
            fields.append({
                "label": join_lines([f for _, f in cand]),
                "value": join_lines(vals),
                "confidence": round(min((v["score"] for v in vals), default=0.0), 4),
                "box": list(r),
            })
            left_limit = r[2]

    leftovers = [f["text"] for k, f in enumerate(free) if k not in used and f["text"] not in title]
    return title, fields, leftovers
