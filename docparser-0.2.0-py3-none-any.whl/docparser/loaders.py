"""Загрузка страниц: рендер в картинку + (если есть) текстовый слой.

Все загрузчики — генераторы (img BGR, items | None). items=None означает «нужен OCR».
"""
from pathlib import Path

import cv2
import numpy as np

from .textlayer import pdfplumber_items, pymupdf_items, text_layer_ok

IMG_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
SUPPORTED_EXT = IMG_EXT | {".pdf"}


def load_pages(path: Path, dpi: int = 200, force_ocr: bool = False):
    """PDF (pymupdf) или картинка с диска."""
    path = Path(path)
    if path.suffix.lower() == ".pdf":
        import pymupdf

        with pymupdf.open(path) as doc:
            for p in doc:
                pix = p.get_pixmap(dpi=dpi, colorspace=pymupdf.csRGB)
                arr = np.frombuffer(pix.samples, np.uint8).reshape(pix.h, pix.w, 3)
                img = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
                items = None
                if not force_ocr and text_layer_ok(p.get_text()):
                    items = pymupdf_items(p, dpi / 72)
                yield img, items
        return
    img = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)  # путь с юникодом
    if img is None:
        raise ValueError(f"не удалось прочитать изображение: {path}")
    yield img, None


def plumber_pages(pdf, dpi: int = 200, force_ocr: bool = False):
    """Уже открытый pdfplumber.PDF (повторно файл не читаем)."""
    for page in pdf.pages:
        img = cv2.cvtColor(np.array(page.to_image(resolution=dpi).original.convert("RGB")), cv2.COLOR_RGB2BGR)
        items = None
        # повёрнутые страницы pdfplumber отдаёт в «сырых» координатах -> безопаснее отправить в OCR
        if not force_ocr and not page.rotation and text_layer_ok(page.extract_text() or ""):
            items = pdfplumber_items(page, dpi / 72)
        yield img, items
