"""Командная строка: python -m docparser файлы... -o result.json"""
import argparse
import json
import sys
from pathlib import Path

from .loaders import SUPPORTED_EXT
from .ocr import HttpBackend, PaddleBackend
from .pipeline import parse_file


def main(argv=None):
    ap = argparse.ArgumentParser(prog="docparser", description=__doc__)
    ap.add_argument("inputs", nargs="+", type=Path, help="PDF/изображения или папки")
    ap.add_argument("-o", "--output", type=Path, default=Path("result.json"))
    ap.add_argument("--lang", default="ru", help="язык локального PaddleOCR")
    ap.add_argument("--ocr-url", help="URL внешнего OCR-сервиса (вместо локального PaddleOCR), см. HttpBackend")
    ap.add_argument("--ocr-timeout", type=float, default=300, help="таймаут ответа OCR-сервиса, с (по умолчанию 300)")
    ap.add_argument("--dpi", type=int, default=200)
    ap.add_argument("--force-ocr", action="store_true", help="не использовать текстовый слой PDF")
    a = ap.parse_args(argv)

    files = []
    for p in a.inputs:
        files += sorted(f for f in p.iterdir() if f.suffix.lower() in SUPPORTED_EXT) if p.is_dir() else [p]

    # OCR вызывается только для страниц без текстового слоя; локальная модель грузится при первом вызове
    ocr = HttpBackend(a.ocr_url, timeout=a.ocr_timeout) if a.ocr_url else PaddleBackend(a.lang)
    results = []
    for f in files:
        try:
            results.append(parse_file(f, ocr, a.dpi, a.force_ocr))
        except Exception as e:  # один плохой файл не должен ронять весь пакет
            print(f"[ошибка] {f}: {e}", file=sys.stderr)
            results.append({"file": str(f), "error": str(e)})
    a.output.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"готово: {len(results)} файл(ов) -> {a.output}")
