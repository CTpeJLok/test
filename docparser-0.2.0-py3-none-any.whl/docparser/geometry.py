"""Геометрия прямоугольников (x1, y1, x2, y2) в пикселях."""


def center(b):
    return (b[0] + b[2]) / 2, (b[1] + b[3]) / 2


def v_overlap(a, b):
    """Доля вертикального перекрытия относительно меньшей высоты."""
    o = min(a[3], b[3]) - max(a[1], b[1])
    return o / max(1, min(a[3] - a[1], b[3] - b[1]))


def iou(a, b):
    ix = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua else 0
