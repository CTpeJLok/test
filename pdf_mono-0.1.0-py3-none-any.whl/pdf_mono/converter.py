"""Быстрая конвертация PDF -> монохромный (1 bit) PDF, 300 dpi.

Страницы рендерятся параллельно в процессах (PyMuPDF), порог яркости
применяется в numpy-free режиме через Pillow, результат кодируется CCITT G4.
"""

import io
import os
import multiprocessing as mp

import pymupdf
from PIL import Image, ImageChops, ImageFilter

DPI = 300
BG_SCALE = 4  # во сколько раз уменьшаем картинку для оценки фона
BG_MEDIAN = 9  # окно медианы на уменьшенной картинке (нечётное)
CONTRAST = 18  # насколько пиксель должен быть темнее окружения
ABS_BLACK = 80  # абсолютно тёмное всегда чёрное (сплошные чёрные фигуры)


def _binarize(img: Image.Image) -> Image.Image:
    """Локальная бинаризация: чёрное = темнее локального фона на CONTRAST."""
    small = img.reduce(BG_SCALE).filter(ImageFilter.MedianFilter(BG_MEDIAN))
    local_bg = small.resize(img.size, Image.Resampling.BILINEAR)
    # max(0, bg - px): насколько пиксель темнее фона
    diff = ImageChops.subtract(local_bg, img)
    dark_vs_bg = diff.point(lambda d: 255 if d > CONTRAST else 0)
    very_dark = img.point(lambda p: 255 if p < ABS_BLACK else 0)
    black = ImageChops.lighter(dark_vs_bg, very_dark)
    return ImageChops.invert(black).convert("1", dither=Image.Dither.NONE)


_doc = None


def _init_worker(data: bytes) -> None:
    global _doc
    _doc = pymupdf.open(stream=data, filetype="pdf")


def _render_page(index: int):
    page = _doc[index]
    pix = page.get_pixmap(dpi=DPI, colorspace=pymupdf.csGRAY, alpha=False)
    img = Image.frombytes("L", (pix.width, pix.height), pix.samples)
    buf = io.BytesIO()
    _binarize(img).save(buf, format="TIFF", compression="group4", dpi=(DPI, DPI))
    return buf.getvalue(), page.rect.width, page.rect.height


def convert_pdf_to_mono(data: bytes, workers: int | None = None, timeout: float | None = 120) -> bytes:
    """Конвертирует PDF (bytes) в монохромный PDF (bytes).

    Ничего не пишет на диск. При ошибке или превышении `timeout` (секунды на
    весь документ, None = без ограничения) все рабочие процессы убиваются,
    наружу летит исключение (TimeoutError при таймауте).
    """
    with pymupdf.open(stream=data, filetype="pdf") as src:
        n = len(src)
    workers = min(workers or os.cpu_count() or 1, n)

    if workers > 1:
        pool = mp.get_context().Pool(workers, _init_worker, (data,))
        try:
            pages = pool.map_async(_render_page, range(n), chunksize=1).get(timeout)
        except mp.TimeoutError:
            raise TimeoutError(f"PDF conversion exceeded {timeout}s") from None
        finally:
            pool.terminate()  # убивает воркеров в любом случае
            pool.join()
    else:
        _init_worker(data)
        pages = [_render_page(i) for i in range(n)]

    out = pymupdf.open()
    for tiff, w, h in pages:
        out.new_page(width=w, height=h).insert_image(pymupdf.Rect(0, 0, w, h), stream=tiff)
    result = out.tobytes(garbage=4, deflate=True)
    out.close()
    return result
